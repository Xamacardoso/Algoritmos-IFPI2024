import {readFileSync as rfs} from "fs"
import { getnumber, getstring } from "./utils/io_utils.js";

function has_no_e(palavra){
    for(let i = 0; i < palavra.length; i++){
        if (palavra[i] === 'e'){
            return false;
        }
    }
    return true;
}

function avoids(palavra, letras_proibidas){
    for (let i in letras_proibidas){
        let letra_proibida = palavra[i];
        if (contem_letra(palavra, letra_proibida)){

        }
    }
}

function contem_letra(palavra, letra){
    for (let l of palavra){
        if (l === letra){
            return true;
        }
    }
    return false;
}

function palavras_sem_e(linhas){
    const palavras = [];
    for (let i = 0; i < linhas.length;i++){
        if (has_no_e(linhas[i])){
            palavras.push(linhas[i]);
        }
    }
    return palavras;
}   

function listar_palavras(palavras){
    console.log("---------- Palavras ------------");

    for (let i = 0; i < palavras.length; i++){
        console.log(palavras[i]);
    }
    console.log("--------------------------------");
}

function palavras_n_mais(linhas){
    const n = getnumber("Qual é o mínimo de letras das palavras selecioinadas? ");
    const palavras = [];
    for (let i = 0; i < linhas.length; i++){
        if (linhas[i].length > n){
            palavras.push(linhas[i]);
        }
    }
    return palavras;
}

function carregarLinhas(){
    return rfs("words.txt", "utf-8").split("\n");

}

function main(){
    const linhas = carregarLinhas();
    const proibidas = getstring("Letras Proibidas: ")
    const palavras = palavras_n_mais(linhas);
    listar_palavras(palavras)
}

main();